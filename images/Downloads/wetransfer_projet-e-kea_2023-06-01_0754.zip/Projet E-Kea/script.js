function demarrage() {
  let chargement = setTimeout(affichageDeLaPage, 2000);
}

function affichageDeLaPage() {
  document.getElementById("loader-fullscreen").style.display = "none";
  document.getElementById("conteneur-chargement").style.display = "block";
}
